import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Segment, Card} from 'semantic-ui-react';
import Dash from './components/client_dashboard';
function App() {
  return (
    <div className="App">
      <Dash></Dash>
    </div>
  );
}

export default App;
