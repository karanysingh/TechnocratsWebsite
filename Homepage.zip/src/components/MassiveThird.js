import React from 'react';
import {Image,Button, Grid, GridColumn, Segment, Sidebar} from 'semantic-ui-react';
class MassiveThd extends React.Component {
    render(){
    return(
        <Grid centered stackable columns={16} padded> 

            <Grid.Row columns={5} className="sect31">
                
            <Grid.Column centered width={3} style={{marginTop:"50px"}}>
                  
                  <span className='DivOneHead'>
                  <span className='DivThreeHead'>Lets Start Your Journey</span>
                    
                    <Grid.Column width={1}>
                    <Button className='DivThreeBtn' color='olive'>Olive</Button>
                   </Grid.Column>

                   <Grid.Column width={1}>
                    <div className='DivThreeImage'>
                        <img className='divIm34' src="Asset 106.svg"></img>
                        <img className='divIm31' src="Asset 107.svg"></img>
                        <img className='divIm32' src="Asset 108.svg"></img>
                        <img className='divIm33' src="Asset 109.svg"></img>
                    </div>
                    </Grid.Column>
                    </span>
                </Grid.Column>
                
            </Grid.Row>
            <Grid.Row className="sect32">
                
            </Grid.Row>
        </Grid>
    )}
}


export default MassiveThd;