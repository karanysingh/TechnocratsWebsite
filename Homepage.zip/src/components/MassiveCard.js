import React from 'react';
import {Image,Button, Grid, GridColumn, Segment, Sidebar} from 'semantic-ui-react';
class MassiveCard extends React.Component {
    render(){
    return(
        <Grid  centered stackable columns={16} padded> 
            <Grid.Row className="sect11">

            </Grid.Row>
            <Grid.Row className="sect12">
                <Grid.Column centered width={3} style={{marginTop:"50px"}}>
                  <span className='DivOneHead'>
                    <h1>Lorem Ipsum dolor sit</h1>
                    <p>You can do the same using shorthands Menu item text can be defined with the content prop The name prop will be used for content if neither children nor content props are defined</p>
                    <Grid.Column width={1}>
                    <Image className='DivOneImage' src={'man.png'}></Image>
                    </Grid.Column>
                    <Grid.Column width={1}>
                    <Button className='DivOneBtn' color='olive'>Olive</Button>
                   </Grid.Column>
                    </span>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )}
}


export default MassiveCard;